from room import *
from maze import *

my_rooms = []
my_rooms.append(Room("This room is the entrance."))
my_rooms.append(Room("This room is the living room, there's a corpse in the closet."))
my_rooms.append(Room("This room is the closet, you're standing next to a corpse."))
my_rooms.append(Room("You're in the kitchen, time to open the fridge five times."))
my_rooms.append(Room("This room has a rick. rick roll."))
my_rooms.append(Room("You're in a room with an engineering major, s/he has a lot of homework."))
my_rooms.append(Room("This is the puppy room, you are suffocating."))
my_rooms.append(Room("You're in a room with a Drexel student. You wallet is now empty."))
my_rooms.append(Room("This is the pool. Rich, I know."))
my_rooms.append(Room("This is the exit, good think you made it out alive cause I sure didn't."))


#room 0 is west of room 1
my_rooms[0].setEast(my_rooms[1])
my_rooms[1].setWest(my_rooms[0])

#Room 1 is west of room 2
my_rooms[1].setEast(my_rooms[2])
my_rooms[2].setWest(my_rooms[1])

#Room 2 is north of room 3
my_rooms[2].setSouth(my_rooms[3])
my_rooms[3].setNorth(my_rooms[2])

#Room 3 is north of room 4
my_rooms[3].setSouth(my_rooms[4])
my_rooms[4].setNorth(my_rooms[3])

#Room 4 is west of room 5
my_rooms[4].setEast(my_rooms[5])
my_rooms[5].setWest(my_rooms[4])

#Room 4 is east of room 6
my_rooms[4].setWest(my_rooms[6])
my_rooms[6].setEast(my_rooms[4])

#Room 5 is north of room 9
my_rooms[5].setSouth(my_rooms[9])

#Room 6 is north of room 7
my_rooms[6].setSouth(my_rooms[7])
my_rooms[7].setNorth(my_rooms[6])

#Room 7 is west of room 8
my_rooms[7].setEast(my_rooms[8])
my_rooms[8].setWest(my_rooms[7])

#Room 8 is west of room 9
my_rooms[8].setEast(my_rooms[9])

    
#Make a maze!
#Set the start and exit rooms.
my_maze = Maze(my_rooms[0],my_rooms[9])
print(my_maze.getCurrent().__str__())

while my_maze.getCurrent() != my_maze.getExit():
    travel = input('Enter direction to move north west east south restart\n').strip().lower()
    
    if travel == 'north':
        moved = my_maze.moveNorth()
        if moved == True:
            print(my_maze.getCurrent().__str__())
        else:
            print('Nope, can\'t go this way')
            
    elif travel == 'south':
        moved = my_maze.moveSouth()
        if moved == True:
            print(my_maze.getCurrent().__str__())
        else:
            print('Nope, can\'t go this way')
    
    elif travel == 'east':
        moved = my_maze.moveEast()
        if moved == True:
            print(my_maze.getCurrent().__str__())
        else:
            print('Nope, can\'t go this way')
            
    elif travel == 'west':
        moved = my_maze.moveWest()
        if moved == True:
            print(my_maze.getCurrent().__str__())
        else:
            print('Nope, can\'t go this way')
            
    elif travel == 'reset':
        my_maze.reset()
        print('You\'re back at the beginning')
        print(my_maze.getCurrent().__str__())
        
    else:
        print('Not a valid movement')